## INSTALACION 
1. Clonar
```
git clone https://github.com/JMJAlfonso/grupo4-losMessianos.git
```
2. Colocarse dentro del directorio APP e instalar dependencias
```
npm install
```
3. Para iniciar el proyecto se debe correr con el siguiente comando:  
```
npm start
```